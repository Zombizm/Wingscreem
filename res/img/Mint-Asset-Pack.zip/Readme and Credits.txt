If you use these assets please credit Maui Game Studio for tiles and Codemora for portraits. The backgrounds are from a different user, please check out there stuff. You are welcome to use the planets and asteriods without crediting us since they are just pixelated stock photography.

Join our discord if you'd like to get ahold of Codemora or I (Joe, Maui Game Studio).

https://discord.com/invite/g2ksjJx